#ifndef RAM_SEGMENTS_H_8EDB9N09UD__
#define RAM_SEGMENTS_H_8EDB9N09UD__

PROCESS_NAME(ram_segments_cleanup_process);

#endif /* RAM_SEGMENTS_H_8EDB9N09UD__ */
